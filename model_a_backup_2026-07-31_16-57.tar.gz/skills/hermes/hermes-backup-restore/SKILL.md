---
name: hermes-backup-restore
description: "Restore Hermes from tar.gz backups safely."
---

# Hermes Backup and Restore

Restore a Hermes Agent installation from a tar.gz backup archive.

## When to Use
- User provides a backup file (tar.gz, git repo) and asks to restore
- Migrating Hermes to a new machine/container
- Recovering from a corrupted installation

## Key Paths
- ~/.hermes/.env — API keys (must be mode 600)
- ~/.hermes/config.yaml — Settings (use hermes config set, never hand-edit)
- ~/.hermes/memories/ — USER.md and MEMORY.md
- ~/.hermes/skills/ — Installed skills
- ~/.hermes/state.db — Session database
- ~/.hermes/cron/ — Scheduled tasks
- ~/.hermes/sessions/ — Session routing
- ~/.hermes/auth.json — OAuth tokens

## Workflow

### 1. Extract and Survey
```bash
mkdir -p /tmp/hermes-restore && tar -xzf backup.tar.gz -C /tmp/hermes-restore
tar -tzf backup.tar.gz | head -80
```

### 2. Restore Memories
```bash
cp extracted/memories/USER.md ~/.hermes/memories/
cp extracted/memories/MEMORY.md ~/.hermes/memories/
```

### 3. Restore .env
```bash
cp extracted/.env ~/.hermes/.env && chmod 600 ~/.hermes/.env
```

### 4. Merge Config.yaml (CRITICAL)
DO NOT blindly overwrite config.yaml. The backup may have model settings from a different environment.

1. Read both current and backup config.yaml
2. Keep current model/provider settings intact
3. Merge non-model settings using hermes config set KEY VAL
4. Use /opt/venv/bin/hermes if hermes not in PATH

Merge from backup: telegram.*, platforms.*, onboarding.seen.*
Do NOT merge: model.*, auxiliary.* (environment-specific)

### 5. Restore Custom Skills
Only copy skills that don't already exist. Also restore .curator_state, .bundled_manifest, .usage.json.

### 6. Restore State Files
Copy cron/, state.db, kanban.db, verification_evidence.db, auth.json, sessions/, channel_directory.json, .initialized, sandboxes/, kanban/, state/, gateway/, scripts/.

### 7. Verify
Run hermes doctor. Check config version, SQLite, tools, memory, sessions.

## References
- `references/verification-checklist.md` — Step-by-step verification after restore
- `references/config-merging.md` — Detailed guide for merging config.yaml safely

## Pitfalls
- Config overwrite breaks model settings — always merge selectively
- .env and auth.json must be mode 600
- Stale state.db may conflict with current sessions
- User-owned skills should not be overwritten
- In containers use /opt/venv/bin/hermes for config commands
- **Path resolution**: `write_file("~/.hermes/...")` writes to `/root/.hermes/...`, NOT `/data/.hermes/...`. Always use the fully resolved absolute path (check with `readlink -f ~/.hermes`). This caused a backup script to be written to the wrong directory during restore.
- **Old backup cleanup**: Before setting up a new backup system, remove old backup artifacts (`/tmp/hermesbackup/`, `/tmp/hermes_backup_*.tar.gz`) to avoid confusion.

## Bidirectional Sync (Two Models Sharing Memory)

When two Hermes models need to share memories, skills, and config, use a **bidirectional sync pattern** via a shared GitHub repo:

1. Each model has a **sync script** (`scripts/sync.sh`) that:
   - Pulls the other model's latest backup from the repo
   - Extracts to a temp directory (OUTSIDE the repo — never extract into the git working tree)
   - Compares memories (`USER.md`, `MEMORY.md`) using `diff -q`
   - Compares skills and config
   - Merges any differences (copies changed files, creates `.bak` backups)
   - Creates its own backup tar.gz
   - Pushes only the tar.gz to the repo (`git add *.tar.gz`, NOT `git add -A`)

2. A **cron job** runs the sync script every 12 hours.

### Critical: Don't Commit Extracted Data to Git

The sync script must extract the other model's backup to a directory **outside** the cloned repo:

```bash
# WRONG — extracts into repo, commits 500+ files of skill data
cd "$SYNC_DIR/repo"
tar xzf "$BACKUP_FILE"   # now repo/extracted/ has all the data
git add -A               # commits everything!

# RIGHT — extracts outside repo, only commits our tar.gz
mkdir -p "$SYNC_DIR/extracted"
cd "$SYNC_DIR/extracted"
tar xzf "$SYNC_DIR/repo/$OTHER_BACKUP"
# ... merge logic ...
cd "$SYNC_DIR/repo"
git add *.tar.gz          # only tar.gz files
```

### What Gets Synced

| Synced | Why |
|--------|-----|
| `memories/USER.md` | User profile — both models need to know the user |
| `memories/MEMORY.md` | Operational notes — shared context |
| `skills/` (custom) | User-created skills should be shared |
| `config.yaml` | Telegram settings, etc. (merge carefully — model settings differ) |

| NOT Synced | Why |
|------------|-----|
| `.env` | API keys may differ per environment |
| `auth.json` | OAuth tokens are per-environment |
| `state.db` | Session state is environment-specific |
| `sessions/` | Session routing is per-environment |

## Backup (outgoing)
For creating automated backups to GitHub, see `scheduled-task-setup` skill — specifically `references/github-backup-script.md` for the full tested script with selective file inclusion.