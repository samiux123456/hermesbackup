# GitHub Backup Script (Tested & Working)

Full tested backup script for automated Hermes backups to a private GitHub repo via HTTPS.

## Tested Environment
- Container: Debian 13 (bookworm), Python 3.11
- SSH port 22: BLOCKED — must use HTTPS
- Repo: private, requires PAT in URL
- Backup size: ~3.3 MB (selective inclusion)
- Cron: every 12 hours via Hermes cronjob tool

## Full Script

```bash
#!/bin/bash
# Hermes Backup Script - backs up critical data to GitHub
set -e

HERMES_DIR="$HOME/.hermes"
BACKUP_DIR="/tmp/hermesbackup"
DATE=$(date '+%Y-%m-%d_%H-%M')
BACKUP_FILE="hermes_backup_${DATE}.tar.gz"
REPO_URL="https://<PAT>@github.com/<user>/<repo>.git"

# Clean previous
rm -rf "$BACKUP_DIR"
mkdir -p "$BACKUP_DIR"

# Create tar.gz of critical Hermes data
cd "$HERMES_DIR"

tar czf "${BACKUP_DIR}/${BACKUP_FILE}" \
    --exclude='*.lock' \
    --exclude='gateway.pid' \
    --exclude='cache/documents/*' \
    --exclude='cache/delegation/*' \
    --exclude='cache/sessions/*' \
    --exclude='cache/skills/*' \
    --exclude='cache/text/*' \
    --exclude='cache/voice/*' \
    --exclude='cache/audio_cache/*' \
    --exclude='cache/image_cache/*' \
    --exclude='logs/*' \
    --exclude='sessions/request_dump_*' \
    memories/ \
    skills/ \
    cron/jobs.json \
    cron/executions.db \
    state.db \
    kanban.db \
    verification_evidence.db \
    channel_directory.json \
    auth.json \
    config.yaml \
    SOUL.md \
    .env \
    .initialized \
    scripts/backup.sh 2>/dev/null || true

# Check backup was created
if [ ! -f "${BACKUP_DIR}/${BACKUP_FILE}" ]; then
    echo "❌ Backup file not created!"
    exit 1
fi

echo "📦 Backup created: $(ls -lh ${BACKUP_DIR}/${BACKUP_FILE} | awk '{print $5}')"

# Clone the repo (shallow)
cd "$BACKUP_DIR"
rm -rf repo
git clone --depth 1 "$REPO_URL" repo 2>/dev/null || true
cd repo

# Remove old backup files
rm -f *.tar.gz 2>/dev/null || true

# Copy new backup
cp "${BACKUP_DIR}/${BACKUP_FILE}" .

# Commit and push
git config user.email "hermes-backup@bot"
git config user.name "Hermes Backup Bot"
git add -A
git commit -m "Backup: $DATE" 2>/dev/null || true
git push origin main 2>/dev/null

echo "✅ Backup pushed to GitHub: $BACKUP_FILE"

# Clean up
cd /
rm -rf "$BACKUP_DIR"
```

## Cron Job Setup

```python
cronjob(
    action="create",
    name="hermes-backup-12h",
    schedule="every 12h",
    prompt="Run the Hermes backup script at /data/.hermes/scripts/backup.sh using bash. Report the result — whether it succeeded, the backup file name, and its size. If it fails, report the error."
)
```

## Key Design Decisions

1. **Selective inclusion over exclusion**: Explicitly list what to back up rather than tar everything and exclude. More predictable, smaller archives.

2. **`--depth 1` clone**: Each backup run does a fresh shallow clone. This avoids git history bloat and merge conflicts.

3. **Old backup cleanup**: `rm -f *.tar.gz` before copying new one — keeps only the latest backup in the repo.

4. **`|| true` on tar**: Prevents script from failing if some excluded paths don't exist.

5. **Token in URL**: PAT embedded in REPO_URL for HTTPS auth when SSH port 22 is blocked.

## Verification

After setting up, verify the backup landed in the repo:
```bash
curl -s -H "Authorization: token <PAT>" \
  https://api.github.com/repos/<user>/<repo>/contents/ | \
  python3 -c "import sys,json; [print(f['name'], f['size']) for f in json.load(sys.stdin) if f['name'].endswith('.tar.gz')]"
```
