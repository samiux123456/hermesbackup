# Bidirectional Sync Script

Tested sync script for sharing memories between two Hermes models via GitHub.

## How It Works

1. Clone the shared repo
2. Find the other model's latest backup (by timestamp)
3. Extract to a temp directory OUTSIDE the repo
4. Compare and merge: USER.md, MEMORY.md, skills, config
5. Create our own backup
6. Push only the tar.gz (not extracted files)

## Full Script

```bash
#!/bin/bash
# sync.sh — bidirectional sync between two Hermes models
set -e

HERMES_DIR="$HOME/.hermes"
SYNC_DIR="/tmp/hermessync"
REPO_URL="https://<PAT>@github.com/<user>/<repo>.git"
DATE=$(date '+%Y-%m-%d_%H-%M')
BACKUP_FILE="hermes_backup_${DATE}.tar.gz"

rm -rf "$SYNC_DIR" && mkdir -p "$SYNC_DIR"
cd "$SYNC_DIR" && git clone --depth 1 "$REPO_URL" repo 2>/dev/null || true
cd repo

OTHER_BACKUP=$(ls -t hermes_backup_*.tar.gz 2>/dev/null | head -1)
[ -z "$OTHER_BACKUP" ] && echo "❌ No backup found" && exit 1
echo "📦 Found: $OTHER_BACKUP"

# Extract OUTSIDE repo
mkdir -p "$SYNC_DIR/extracted"
tar xzf "$SYNC_DIR/repo/$OTHER_BACKUP" 2>/dev/null || true

# Compare & merge memories
echo "🧠 Comparing memories..."
for f in USER.md MEMORY.md; do
    if [ -f "$SYNC_DIR/extracted/memories/$f" ]; then
        if ! diff -q "$HERMES_DIR/memories/$f" "$SYNC_DIR/extracted/memories/$f" >/dev/null 2>&1; then
            cp "$HERMES_DIR/memories/$f" "$HERMES_DIR/memories/$f.bak"
            cp "$SYNC_DIR/extracted/memories/$f" "$HERMES_DIR/memories/$f"
            echo "✅ $f updated"
        else
            echo "✓ $f unchanged"
        fi
    fi
done

# Compare & merge skills
echo "🛠️ Comparing skills..."
if [ -d "$SYNC_DIR/extracted/skills" ]; then
    for skill_dir in "$SYNC_DIR/extracted/skills"/*/; do
        skill_name=$(basename "$skill_dir")
        [[ "$skill_name" == .* ]] && continue
        if [ -f "$skill_dir/SKILL.md" ] && [ -f "$HERMES_DIR/skills/$skill_name/SKILL.md" ]; then
            if ! diff -q "$HERMES_DIR/skills/$skill_name/SKILL.md" "$skill_dir/SKILL.md" >/dev/null 2>&1; then
                cp "$HERMES_DIR/skills/$skill_name/SKILL.md" "$HERMES_DIR/skills/$skill_name/SKILL.md.bak"
                cp "$skill_dir/SKILL.md" "$HERMES_DIR/skills/$skill_name/SKILL.md"
                echo "✅ Skill $skill_name updated"
            fi
        elif [ ! -d "$HERMES_DIR/skills/$skill_name" ]; then
            cp -r "$skill_dir" "$HERMES_DIR/skills/"
            echo "📥 New skill: $skill_name"
        fi
    done
fi

# Compare config
if [ -f "$SYNC_DIR/extracted/config.yaml" ]; then
    if ! diff -q "$HERMES_DIR/config.yaml" "$SYNC_DIR/extracted/config.yaml" >/dev/null 2>&1; then
        cp "$HERMES_DIR/config.yaml" "$HERMES_DIR/config.yaml.bak"
        cp "$SYNC_DIR/extracted/config.yaml" "$HERMES_DIR/config.yaml"
        echo "✅ Config updated"
    fi
fi

# Create our backup & push ONLY tar.gz
cd "$HERMES_DIR"
tar czf "${SYNC_DIR}/${BACKUP_FILE}" \
    --exclude='*.lock' --exclude='gateway.pid' \
    --exclude='cache/*' --exclude='logs/*' --exclude='sessions/request_dump_*' \
    memories/ skills/ cron/ state.db kanban.db auth.json config.yaml SOUL.md .env scripts/ 2>/dev/null || true

cd "$SYNC_DIR/repo"
rm -f hermes_backup_*.tar.gz 2>/dev/null || true
cp "${SYNC_DIR}/${BACKUP_FILE}" .
git config user.email "hermes-sync@bot"
git config user.name "Hermes Sync Bot"
git add *.tar.gz  # NEVER git add -A!
git commit -m "Sync: $DATE" 2>/dev/null || true
git push origin main 2>/dev/null

echo "✅ Sync completed: $BACKUP_FILE"
rm -rf "$SYNC_DIR"
```

## Cron Job Setup

```
cronjob(
    action="create",
    name="hermes-sync-12h",
    schedule="every 12h",
    prompt="Run the sync script at /data/.hermes/scripts/sync.sh using bash. Report what was synced."
)
```

## Pitfalls

1. **Never `git add -A` after extracting** — commits hundreds of extracted skill files
2. **Extract outside the repo** — use `$SYNC_DIR/extracted`, not `$SYNC_DIR/repo/extracted`
3. **Skip hidden dirs** — `[[ "$skill_name" == .* ]]` to avoid `.bundled_manifest` etc.
4. **Environment-specific files** — `.env`, `auth.json`, `state.db` should NOT be synced
