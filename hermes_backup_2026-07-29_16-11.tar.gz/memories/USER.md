GitHub username: samiux123456. Has a backup repo at github.com/samiux123456/hermesbackup.
§
Sami (سامی): Python dev, Telegram bots/MTProto proxy. Calls me "داش" (dāsh/bro). Prefers Persian. Wants complete runnable code, not fragments. Modular architecture (Interface/Logic/Data). University student (اندیشه اسلامی). Peugeot 405. Old house in Kocheh-Bagh (garden-facing, desert behind). Persepolis fan. Hayedeh music. Railway $5 free tier. Uses Chatbox for LLM chats. Context window workaround: export chat → new chat → upload file → continue. Smart, solution-oriented, casual tone.
§
Sami has a day job (works morning and afternoon with lunch break). Evenings are for personal projects. Currently working on a project called "اسم و فامیل" (Name & Surname project) - needs to complete it.
§
Sami uses Chatbox as primary chat interface with mimohermes. Railway budget: $5 free tier. Calls me "داش" (bro). Prefers Persian communication. Wants to export Chatbox history and feed it to me for context continuity.
§
User: Sami. Casual/mahvaraei Persian - use very casual slang like real friends
§
Sami wants very casual slangy Persian chat style (like real friends). Cannot see animated stickers. Currently working on name-surname project (50-60% done). Wants to build Telegram self-bot after finishing current project.