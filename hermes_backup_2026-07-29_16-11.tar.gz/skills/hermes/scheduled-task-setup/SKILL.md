---
name: scheduled-task-setup
description: "Create and debug Hermes cron jobs for backups."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [cron, scheduled-tasks, backup, automation]
    related_skills: [hermes-agent]
---

# Scheduled Task Setup (Hermes Cron Jobs)

How to create, configure, and debug scheduled tasks using the `cronjob` tool.

## Trigger

Use this skill when:
- User wants to schedule recurring tasks (backups, monitoring, reports)
- Cron job fails with "no model configured" error
- Setting up automated GitHub backups
- Any `cronjob` tool usage

## Creating a Cron Job

### Minimal Example

```
cronjob(action="create", schedule="every 12h", prompt="Run the backup script at /path/to/script.sh using bash. Report success or failure.")
```

### With Model (RECOMMENDED)

Always specify a model to avoid failures:

```
cronjob(
    action="create",
    schedule="every 12h",
    prompt="...",
    model={"model": "mimohermes", "provider": "openai-api"}
)
```

### Full Example with Script

```
cronjob(
    action="create",
    schedule="0 9 * * *",
    name="daily-backup",
    prompt="Run the backup script and report results.",
    model={"model": "mimohermes", "provider": "openai-api"},
    enabled_toolsets=["terminal"]
)
```

## ⚠️ Critical Pitfall: Missing Model

**The #1 cause of cron job failures.**

If you create a cron job without specifying a model AND no default model is configured in `config.yaml`, the job will fail with:

```
RuntimeError: Cron job 'xxx' has no model configured
(job.model=None, HERMES_MODEL='', config.yaml model.default missing or empty)
```

**Fix:**
```
cronjob(action="update", job_id="THE_JOB_ID", model={"model": "mimohermes", "provider": "openai-api"})
```

**Prevention:** Always pass `model=` when creating cron jobs.

## Pitfall: Fresh System Git Config

When creating backup scripts that use `git commit/push` on a fresh system:

```bash
# MUST run git config first, or commits will fail:
git config --global user.email "bot@nova"
git config --global user.name "Hermes Backup"
```

## Schedule Formats

| Format | Example | Description |
|--------|---------|-------------|
| Duration | `"30m"`, `"2h"` | Every N minutes/hours |
| Every phrase | `"every monday 9am"` | Natural language |
| Cron expression | `"0 9 * * *"` | Standard 5-field cron |
| ISO timestamp | `"2026-06-01T09:00:00"` | One-shot |

## Managing Jobs

```
# List all jobs
cronjob(action="list")

# Run a job immediately
cronjob(action="run", job_id="THE_JOB_ID")

# Pause/resume
cronjob(action="pause", job_id="THE_JOB_ID")
cronjob(action="resume", job_id="THE_JOB_ID")

# Remove
cronjob(action="remove", job_id="THE_JOB_ID")

# Update model on existing job
cronjob(action="update", job_id="THE_JOB_ID", model={"model": "mimohermes", "provider": "openai-api"})
```

## Backup Script Pattern

For GitHub-based backups (port 22 blocked):

```bash
#!/bin/bash
set -e

BACKUP_DIR="/tmp/hermesbackup"
HERMES_DIR="$HOME/.hermes"
DATE=$(date '+%Y-%m-%d_%H-%M')
BACKUP_FILE="backup_${DATE}.tar.gz"

# Ensure git is configured
git config --global user.email "bot@backup" 2>/dev/null || true
git config --global user.name "Hermes Backup" 2>/dev/null || true

# Create backup archive
cd "$HERMES_DIR"
tar czf "/tmp/$BACKUP_FILE" \
    --exclude='*.lock' \
    --exclude='audio_cache' \
    --exclude='image_cache' \
    --exclude='cache' \
    --exclude='logs' \
    .

# Push to GitHub
mv "/tmp/$BACKUP_FILE" "$BACKUP_DIR/"
cd "$BACKUP_DIR"
git add -A
git commit -m "Backup: ${DATE}" || echo "No changes"
git push origin main
```

## Restore from Backup

See `references/restore-process.md` for step-by-step restore instructions. User asked about this explicitly — always mention restore capability when discussing backups.

## Railway CLI Setup

If backup target is on Railway, you may need to check usage/balance. See `references/railway-cli-auth.md` for token setup and usage queries.

**Key pitfall:** Railway tokens must be **Account Tokens** (full access), not Project Tokens. Project-scoped tokens return "Not Authorized" for usage queries.

## Diagnosing Failures

Check cron output logs:
```bash
ls ~/.hermes/cron/output/<job_id>/
cat ~/.hermes/cron/output/<job_id>/*.log | tail -50
```

Common errors:
| Error | Cause | Fix |
|-------|-------|-----|
| `no model configured` | Missing model param | `cronjob action=update model=...` |
| `Author identity unknown` | Git not configured | `git config --global user.email/name` |
| `Permission denied` (push) | Bad token or repo | Check token scopes, repo URL |
