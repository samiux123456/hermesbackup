# Backup Restore Process

User explicitly asked "چجوری میشه از بکاپ استفاده کرد؟" (how to use the backup).

## Steps

```bash
# 1. Clone the backup repo
cd /tmp
git clone https://github.com/<user>/<repo>.git

# 2. Find the latest backup
ls /tmp/<repo>/*.tar.gz

# 3. Extract to Hermes directory
cd ~/.hermes
tar -xzf /tmp/<repo>/hermes_backup_XXXX-XX-XX_XX-XX.tar.gz

# 4. Restart Hermes
# systemd:
sudo systemctl restart hermes
# manual:
hermes restart
```

## Safety

Always keep the current state before restoring. The backup only covers:
- memories/
- skills/
- sessions/sessions.json
- cron/
- config.yaml, SOUL.md, state.db, kanban.db, auth.json, .env, channel_directory.json

Excluded (regenerable): cache/, logs/, audio_cache/, image_cache/, *.lock, gateway.pid, large cache JSONs.
