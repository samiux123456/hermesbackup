#!/bin/bash
# Hermes Backup Script - backs up critical data to GitHub
set -e

BACKUP_DIR="/tmp/hermesbackup"
HERMES_DIR="$HOME/.hermes"
DATE=$(date '+%Y-%m-%d_%H-%M')
BACKUP_FILE="hermes_backup_${DATE}.tar.gz"

# Clean previous backup
rm -f "$BACKUP_DIR"/*.tar.gz

# Create tar.gz of critical Hermes data
# Include: memories, skills, sessions, cron, config, SOUL.md, state.db, kanban.db, kanban/, auth.json, .env, channel_directory.json
# Exclude: cache, logs, audio_cache, image_cache, lock files, pid files, large cache jsons
cd "$HERMES_DIR"

tar czf "/tmp/$BACKUP_FILE" \
    --exclude='*.lock' \
    --exclude='gateway.pid' \
    --exclude='audio_cache' \
    --exclude='image_cache' \
    --exclude='cache' \
    --exclude='logs' \
    --exclude='models_dev_cache.json' \
    --exclude='provider_models_cache.json' \
    --exclude='ollama_cloud_models_cache.json' \
    --exclude='.skills_prompt_snapshot.json' \
    --exclude='gateway-starts.log' \
    --exclude='gateway.lock' \
    --exclude='gateway.pid' \
    --exclude='gateway_state.json' \
    --exclude='pairing' \
    --exclude='bin' \
    --exclude='hooks' \
    --exclude='platforms' \
    --exclude='kanban/.dispatcher.lock' \
    --exclude='kanban.db.dispatch.lock' \
    --exclude='kanban.db.init.lock' \
    --exclude='cron/.tick.lock' \
    --exclude='cron/.jobs.lock' \
    --exclude='cron/ticker_heartbeat' \
    --exclude='cron/ticker_last_success' \
    --exclude='cron/output' \
    .

# Move backup to repo
mv "/tmp/$BACKUP_FILE" "$BACKUP_DIR/"

# Push to GitHub
cd "$BACKUP_DIR"
git add -A
git commit -m "Backup: ${DATE}" || echo "No changes to commit"
git push origin main 2>&1

echo "✅ Backup ${BACKUP_FILE} pushed to GitHub successfully!"
echo "📦 Size: $(du -h "$BACKUP_DIR/$BACKUP_FILE" | cut -f1)"
