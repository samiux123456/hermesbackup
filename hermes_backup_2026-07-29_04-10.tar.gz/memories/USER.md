User's name is Sami. Speak in Persian (Farsi) with him.
§
GitHub username: samiux123456. Has a backup repo at github.com/samiux123456/hermesbackup.
§
Sami: Python developer, Telegram bot/MTProto proxy projects. Prefers structured checklists, complete code (not fragments), modular architecture (Interface/Logic/Data). University student (اندیشه اسلامی). Peugeot 405 owner. Old house in Kocheh-Bagh (garden-facing, desert behind, needs renovation). Persepolis football fan. Likes Hayedeh music. Values clean formatting and precise text output.
§
Sami has a day job (works morning and afternoon with lunch break). Evenings are for personal projects. Currently working on a project called "اسم و فامیل" (Name & Surname project) - needs to complete it.