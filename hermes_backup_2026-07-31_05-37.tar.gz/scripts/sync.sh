#!/bin/bash
# Hermes Sync Script - bidirectional sync with other model
set -e

HERMES_DIR="$HOME/.hermes"
SYNC_DIR="/tmp/hermessync"
REPO_URL="https://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@github.com/samiux123456/hermesbackup.git"
DATE=$(date '+%Y-%m-%d_%H-%M')
BACKUP_FILE="hermes_backup_${DATE}.tar.gz"

# Clean previous sync dir
rm -rf "$SYNC_DIR"
mkdir -p "$SYNC_DIR"

# Clone repo
cd "$SYNC_DIR"
git clone --depth 1 "$REPO_URL" repo 2>/dev/null || true
cd repo

# Find the other model's backup (not ours)
OTHER_BACKUP=$(ls -t hermes_backup_*.tar.gz 2>/dev/null | head -1)

if [ -z "$OTHER_BACKUP" ]; then
    echo "❌ No backup found from other model"
    exit 1
fi

echo "📦 Found other model's backup: $OTHER_BACKUP"

# Extract to temp dir (outside repo)
mkdir -p "$SYNC_DIR/extracted"
cd "$SYNC_DIR/extracted"
tar xzf "$SYNC_DIR/repo/$OTHER_BACKUP" 2>/dev/null || true

# Compare and merge memories
echo "🧠 Comparing memories..."
if [ -d "memories" ]; then
    if [ -f "memories/USER.md" ]; then
        if ! diff -q "$HERMES_DIR/memories/USER.md" "memories/USER.md" >/dev/null 2>&1; then
            echo "📝 USER.md changed - merging..."
            cp "$HERMES_DIR/memories/USER.md" "$HERMES_DIR/memories/USER.md.bak"
            cp "memories/USER.md" "$HERMES_DIR/memories/USER.md"
            echo "✅ USER.md updated from other model"
        else
            echo "✓ USER.md unchanged"
        fi
    fi
    
    if [ -f "memories/MEMORY.md" ]; then
        if ! diff -q "$HERMES_DIR/memories/MEMORY.md" "memories/MEMORY.md" >/dev/null 2>&1; then
            echo "📝 MEMORY.md changed - merging..."
            cp "$HERMES_DIR/memories/MEMORY.md" "$HERMES_DIR/memories/MEMORY.md.bak"
            cp "memories/MEMORY.md" "$HERMES_DIR/memories/MEMORY.md"
            echo "✅ MEMORY.md updated from other model"
        else
            echo "✓ MEMORY.md unchanged"
        fi
    fi
fi

# Compare and merge skills
echo "🛠️ Comparing skills..."
if [ -d "skills" ]; then
    for skill_dir in skills/*/; do
        if [ -d "$skill_dir" ]; then
            skill_name=$(basename "$skill_dir")
            if [[ "$skill_name" == .* ]]; then
                continue
            fi
            
            if [ -d "$HERMES_DIR/skills/$skill_name" ]; then
                if [ -f "$skill_dir/SKILL.md" ] && [ -f "$HERMES_DIR/skills/$skill_name/SKILL.md" ]; then
                    if ! diff -q "$HERMES_DIR/skills/$skill_name/SKILL.md" "$skill_dir/SKILL.md" >/dev/null 2>&1; then
                        echo "📝 Skill $skill_name changed - merging..."
                        cp "$HERMES_DIR/skills/$skill_name/SKILL.md" "$HERMES_DIR/skills/$skill_name/SKILL.md.bak"
                        cp "$skill_dir/SKILL.md" "$HERMES_DIR/skills/$skill_name/SKILL.md"
                        echo "✅ Skill $skill_name updated"
                    fi
                fi
            else
                echo "📥 New skill: $skill_name"
                cp -r "$skill_dir" "$HERMES_DIR/skills/"
            fi
        fi
    done
fi

# Compare config
echo "⚙️ Comparing config..."
if [ -f "config.yaml" ]; then
    if ! diff -q "$HERMES_DIR/config.yaml" "config.yaml" >/dev/null 2>&1; then
        echo "📝 Config changed - merging..."
        cp "$HERMES_DIR/config.yaml" "$HERMES_DIR/config.yaml.bak"
        cp "config.yaml" "$HERMES_DIR/config.yaml"
        echo "✅ Config updated from other model"
    else
        echo "✓ Config unchanged"
    fi
fi

# Now create our backup and push
echo ""
echo "📦 Creating our backup..."
cd "$HERMES_DIR"

tar czf "${SYNC_DIR}/${BACKUP_FILE}" \
    --exclude='*.lock' \
    --exclude='gateway.pid' \
    --exclude='cache/documents/*' \
    --exclude='cache/delegation/*' \
    --exclude='cache/sessions/*' \
    --exclude='cache/skills/*' \
    --exclude='cache/text/*' \
    --exclude='cache/voice/*' \
    --exclude='cache/audio_cache/*' \
    --exclude='cache/image_cache/*' \
    --exclude='logs/*' \
    --exclude='sessions/request_dump_*' \
    memories/ \
    skills/ \
    cron/jobs.json \
    cron/executions.db \
    state.db \
    kanban.db \
    verification_evidence.db \
    channel_directory.json \
    auth.json \
    config.yaml \
    SOUL.md \
    .env \
    .initialized \
    scripts/ 2>/dev/null || true

# Push our backup (only tar.gz files, no extracted dir)
cd "$SYNC_DIR/repo"
rm -f hermes_backup_*.tar.gz 2>/dev/null || true
cp "../$BACKUP_FILE" .
git config user.email "hermes-sync@bot"
git config user.name "Hermes Sync Bot"
git add "*.tar.gz"
git commit -m "Sync: $DATE" 2>/dev/null || true
git push origin main 2>/dev/null

echo ""
echo "✅ Sync completed!"
echo "📦 Our backup pushed: $BACKUP_FILE"

# Clean up
cd /
rm -rf "$SYNC_DIR"
